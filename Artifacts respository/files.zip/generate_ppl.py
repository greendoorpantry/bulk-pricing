r"""
Generate ppl_0001.xls with bulk prices for CES Touch import.

CRITICAL: Uses Save() not SaveAs() to preserve the original VFP 'Book'
stream format that CES Touch requires.

Updates:
  - price2 = calculated bulk price
  - qty2 = case quantity
  - qtydesc2 = "BULK"

Leaves price0 (unused) and price1 (RRP/EACH) untouched.

Run from C:\BulkPricing:
  python generate_ppl.py
"""

import os
import sys
import json
import math
import shutil

REPO_DIR = r"C:\BulkPricing"
JSON_FILE = os.path.join(REPO_DIR, "data", "bulk_pricing_data.json")
PRODUCTS_FILE = os.path.join(REPO_DIR, "data", "products.xlsx")
CES_PPL_SOURCE = r"C:\Touch\IMP-EXP\ppl_0001.xls"
PPL_OUTPUT = os.path.join(REPO_DIR, "data", "ppl_0001.xls")


def round_to_10c(price):
    return math.ceil(price * 10) / 10


def load_bulk_prices():
    if os.path.exists(JSON_FILE):
        print(f"[INFO] Loading bulk prices from JSON...")
        with open(JSON_FILE, 'r') as f:
            data = json.load(f)
        products = data.get('products', [])
        lookup = {}
        for p in products:
            bc = str(p['barcode']).strip()
            lookup[bc] = {'bulk_price': p['bulkPrice'], 'case_qty': p['caseQty']}
            stripped = bc.lstrip('0')
            if stripped and stripped != bc:
                lookup[stripped] = lookup[bc]
        print(f"  [OK] {len(products)} products")
        return lookup

    if os.path.exists(PRODUCTS_FILE):
        print(f"[INFO] Calculating from products.xlsx...")
        from openpyxl import load_workbook
        wb = load_workbook(PRODUCTS_FILE, read_only=True, data_only=True)
        ws = wb.active
        headers = [str(cell.value or '').strip().lower() for cell in ws[1]]
        col_map = {h: i for i, h in enumerate(headers) if h}
        lookup = {}
        count = 0
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row: continue
            plu = str(row[col_map.get('plu', -1)] or '').strip()
            if not plu: continue
            cost = float(row[col_map.get('cost', -1)] or 0)
            caseqty = int(float(row[col_map.get('caseqty', -1)] or 0))
            nprice1 = float(row[col_map.get('nprice1', -1)] or 0)
            if cost > 0 and caseqty >= 1 and nprice1 > 0:
                bulk_price = round_to_10c(cost * caseqty * 1.1)
                lookup[plu] = {'bulk_price': bulk_price, 'case_qty': caseqty}
                stripped = plu.lstrip('0')
                if stripped and stripped != plu:
                    lookup[stripped] = lookup[plu]
                count += 1
        wb.close()
        print(f"  [OK] {count} products")
        return lookup

    print(f"[ERROR] No data source found")
    return {}


def main():
    print("\n" + "=" * 60)
    print("  GENERATE PPL WITH BULK PRICES (Price Level 2)")
    print("=" * 60)

    bulk_lookup = load_bulk_prices()
    if not bulk_lookup:
        return False

    if not os.path.exists(CES_PPL_SOURCE):
        print(f"[ERROR] PPL file not found: {CES_PPL_SOURCE}")
        return False

    # STEP 1: Copy original to output location (preserves format)
    os.makedirs(os.path.dirname(PPL_OUTPUT) or '.', exist_ok=True)
    shutil.copy2(CES_PPL_SOURCE, PPL_OUTPUT)
    print(f"\n[INFO] Copied original to {PPL_OUTPUT}")

    # STEP 2: Open the COPY (not original) via Excel COM
    print(f"[INFO] Opening copy via Excel...")

    excel = None
    wb = None
    try:
        import win32com.client

        excel = win32com.client.Dispatch("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False

        wb = excel.Workbooks.Open(os.path.abspath(PPL_OUTPUT))
        ws = wb.Sheets(1)

        # Read headers
        headers = {}
        col = 1
        while True:
            val = ws.Cells(1, col).Value
            if val is None or str(val).strip() == '':
                break
            headers[str(val).strip().lower()] = col
            col += 1

        cplu_col = headers.get('cplu', 1)
        price2_col = headers.get('price2')
        qty2_col = headers.get('qty2')
        qtydesc2_col = headers.get('qtydesc2')

        if not all([price2_col, qty2_col, qtydesc2_col]):
            print(f"[ERROR] Missing columns")
            wb.Close(False)
            excel.Quit()
            return False

        last_row = ws.Cells(ws.Rows.Count, cplu_col).End(-4162).Row
        total_rows = last_row - 1
        print(f"  [OK] {total_rows} rows")

        # STEP 3: Batch read all barcodes
        print(f"[INFO] Reading barcodes...")
        cplu_range = ws.Range(ws.Cells(2, cplu_col), ws.Cells(last_row, cplu_col)).Value
        barcodes = [str(row[0]).strip() if row[0] is not None else ''
                    for row in cplu_range]

        # Read existing values
        existing_p2 = ws.Range(ws.Cells(2, price2_col), ws.Cells(last_row, price2_col)).Value
        existing_q2 = ws.Range(ws.Cells(2, qty2_col), ws.Cells(last_row, qty2_col)).Value
        existing_d2 = ws.Range(ws.Cells(2, qtydesc2_col), ws.Cells(last_row, qtydesc2_col)).Value

        # STEP 4: Prepare updates
        print(f"[INFO] Matching products...")
        updates_p2 = []
        updates_q2 = []
        updates_d2 = []
        updated = 0
        no_match = 0

        for i, bc in enumerate(barcodes):
            if not bc:
                updates_p2.append((existing_p2[i][0] if existing_p2 else 0,))
                updates_q2.append((existing_q2[i][0] if existing_q2 else 0,))
                updates_d2.append((existing_d2[i][0] if existing_d2 else '',))
                no_match += 1
                continue

            if bc.endswith('.0'):
                bc = bc[:-2]

            bp = bulk_lookup.get(bc) or bulk_lookup.get(bc.lstrip('0'))

            if bp:
                updates_p2.append((bp['bulk_price'],))
                updates_q2.append((bp['case_qty'],))
                updates_d2.append(('BULK',))
                updated += 1
            else:
                updates_p2.append((existing_p2[i][0] if existing_p2 else 0,))
                updates_q2.append((existing_q2[i][0] if existing_q2 else 0,))
                updates_d2.append((existing_d2[i][0] if existing_d2 else '',))
                no_match += 1

        print(f"\n[RESULT]")
        print(f"  Updated:      {updated}")
        print(f"  No bulk data: {no_match}")

        # STEP 5: Batch write
        print(f"\n[INFO] Writing updates...")
        ws.Range(ws.Cells(2, price2_col), ws.Cells(last_row, price2_col)).Value = updates_p2
        ws.Range(ws.Cells(2, qty2_col), ws.Cells(last_row, qty2_col)).Value = updates_q2
        ws.Range(ws.Cells(2, qtydesc2_col), ws.Cells(last_row, qtydesc2_col)).Value = updates_d2

        # STEP 6: Save() - NOT SaveAs() - preserves original format!
        wb.Save()
        print(f"[SAVED] {PPL_OUTPUT} (original format preserved)")

        wb.Close(False)
        excel.Quit()
        excel = None

        # STEP 7: Copy back to CES Touch
        try:
            shutil.copy2(PPL_OUTPUT, CES_PPL_SOURCE)
            print(f"[COPIED] {CES_PPL_SOURCE}")
        except Exception as e:
            print(f"[WARN] Copy failed: {e}")

        print(f"\n[DONE] Import in CES Touch: Import/Export -> Import -> Price Levels")
        return True

    except ImportError:
        print("[ERROR] pywin32 not installed. Run: pip install pywin32")
        return False
    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()
        if wb:
            try: wb.Close(False)
            except: pass
        if excel:
            try: excel.Quit()
            except: pass
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
